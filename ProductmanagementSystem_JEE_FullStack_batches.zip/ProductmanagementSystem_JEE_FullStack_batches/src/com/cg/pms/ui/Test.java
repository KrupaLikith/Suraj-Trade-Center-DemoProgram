package com.cg.pms.ui;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {

		Scanner scanner = null;
		String input = "";
		boolean inputValue = false;

		do {
			scanner = new Scanner(System.in);
			System.out.println("input");
			input = scanner.nextLine();
			if (input.equalsIgnoreCase("yes")) {
				inputValue = true;
				break;
			} else if (input.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				inputValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				inputValue = false;
				continue;
			}
		} while (!inputValue);

		System.out.println("input is: " + input);

		scanner.close();

	}

}
