package com.cg.pms.utility;

import java.util.ArrayList;
import java.util.List;

import com.cg.pms.dto.Product;

public class PMSUtil {

	private static List<Product> list = new ArrayList<>();

	static {

		list.add(new Product(111, "TV", 45000d, 24));
		list.add(new Product(222, "AC", 55000d, 14));
		list.add(new Product(333, "Fdidge", 25000d, 10));
		list.add(new Product(444, "mobile", 20000d, 102));
		list.add(new Product(555, "bike", 75000d, 5));
	}

	public static List<Product> getList() {
		return list;
	}

	public static void setList(List<Product> list) {
		PMSUtil.list = list;
	}

}
